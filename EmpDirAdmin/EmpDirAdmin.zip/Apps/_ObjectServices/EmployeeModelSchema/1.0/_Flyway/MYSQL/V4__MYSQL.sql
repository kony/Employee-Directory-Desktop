ALTER TABLE `Contact`
	CHANGE `Contact_type` `Contact_type_id` VARCHAR(32) NOT NULL;
