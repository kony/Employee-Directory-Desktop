ALTER TABLE `Employee`
	ADD `image` LONGBLOB;
