ALTER TABLE `Media`
	ADD CONSTRAINT `2bbfe6ca53000e291cfa478112bac8` FOREIGN KEY(`employee_id`) REFERENCES `Employee`(`Employee_id`);
